import sqlalchemy
from .db_session import SqlAlchemyBase
from flask_wtf import FlaskForm
from wtforms import StringField, IntegerField, SubmitField, BooleanField
from wtforms.validators import DataRequired


class Departament(SqlAlchemyBase):
    __tablename__ = 'departament'
    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True, autoincrement=True)  # АЙДИ
    title = sqlalchemy.Column(sqlalchemy.String)
    chief = sqlalchemy.Column(sqlalchemy.Integer, sqlalchemy.ForeignKey("users.id"))
    members = sqlalchemy.Column(sqlalchemy.String)
    email = sqlalchemy.Column(sqlalchemy.String, unique=True)


class DepForm(FlaskForm):
    title = StringField("Название департамента", validators=[DataRequired()])
    chief = IntegerField("ID руководителя", validators=[DataRequired()])
    members = StringField("Участники")
    email = StringField("Почта департамента", validators=[DataRequired()])
