import datetime
import sqlalchemy
from .db_session import SqlAlchemyBase
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, IntegerField, SubmitField, BooleanField
from wtforms.validators import DataRequired
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash


class User(SqlAlchemyBase, UserMixin):
    __tablename__ = 'users'
    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True, autoincrement=True)  # АЙДИ
    surname = sqlalchemy.Column(sqlalchemy.String)  # Фамилия
    name = sqlalchemy.Column(sqlalchemy.String)  # Имя
    age = sqlalchemy.Column(sqlalchemy.INTEGER)  # Возраст
    position = sqlalchemy.Column(sqlalchemy.String)  # Должность
    speciality = sqlalchemy.Column(sqlalchemy.String)  # Профессия
    address = sqlalchemy.Column(sqlalchemy.String)  # Адрес
    email = sqlalchemy.Column(sqlalchemy.String, unique=True)  # Эл. почта
    hashed_password = sqlalchemy.Column(sqlalchemy.String)  # Зашифрованные пароль
    modified_date = sqlalchemy.Column(sqlalchemy.DateTime, default=datetime.datetime.now)  # Дата изменения

    def set_password(self, password):
        self.hashed_password = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.hashed_password, password)


class RegisterForm(FlaskForm):
    name = StringField("Имя", validators=[DataRequired()])
    surname = StringField("Фамилия", validators=[DataRequired()])
    email = StringField("Эл-ная почта", )
    password = PasswordField("Пароль", validators=[DataRequired()])
    password_again = PasswordField("Повторите пароль", validators=[DataRequired()])
    director_code = StringField("Код руководителя", validators=[DataRequired()])
    age = IntegerField("Ваш возраст")
    submit = SubmitField('Зарегистрироваться')


class LoginForm(FlaskForm):
    email = StringField("Эл-ная почта", validators=[DataRequired()])
    password = PasswordField("Пароль", validators=[DataRequired()])
    remember_me = BooleanField('Запомнить меня')
    submit = SubmitField('Войти')
