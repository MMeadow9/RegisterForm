from flask import Flask, render_template, redirect, abort, request
from data.db_session import global_init, create_session
from data.users import User, LoginForm, RegisterForm
from data.jobs import Jobs, JobsForm
from data.departments import Departament
from data.db_session import *
import datetime
import os
from wtforms import Label
from flask_login import LoginManager, login_user, login_required, logout_user, current_user
from random import randint, choices, choice
from werkzeug.security import generate_password_hash


app = Flask(__name__)
app.config['SECRET_KEY'] = ''.join(choices("0123456789ABCDEFabcdef", k=randint(10, 15)))

login_manager = LoginManager()
login_manager.init_app(app)


names = """Anthony Angel Zhanatan Lloyd Luke Alex
 Lewis Matthew Nancy Margaret Rachel Jessica
 Nancy Mary Megan Lucy Darlene Lindsey
 Ulysses Francis Stephen Blak Timothy Isaac
 Virginia Gloria Marjory Marge Martha Frank
 """.split()

surnames = """
Mitchell Adderiy Audley Forman Smith Martin
 Chandter Addington Day Baldwin Dunce
""".split()


@login_manager.user_loader
def load_user(user_id):
    db_sess = create_session()
    return db_sess.query(User).get(user_id)


def load_data():
    if os.path.isfile("db/blogs.db"):
        return
    global_init("db/blogs.db")

    db_sess = create_session()

    new_users = [[choice(names), choice(surnames), randint(18, 36), choice(["Intern"] * 2 + ["Member"]),
                  "assistant", loc, "".join(choices("abcdefghjklABCDEFGHJIKL0123456789__", k=randint(8,
                                                                                                     17))) + "@mars.org"]
                 for loc in [
            "module 4-Δ",
            "module 2-Δ",
            "module 5-H",
            "module 4-H",
            "module 1-Θ",
            "module 6-Θ",
            "module 4-Λ",
            "module 6-Λ",
            "module 5-Ξ",
            "module 4-Σ",
            "module 3-Σ",
            "module 2-Ψ",
            "module 6-Ψ"
                 ]]


    for index, data in enumerate([
        ["Scott", "Ridley", 21, "First Captain", "research engineer", "module 1-B", "scott_chief@mars.org"],
        ["Mary", "Elmers", 23, "Second Captain", "main engineer", "module 2-A", "mary_el01@mars.org"],
        ["Miguel", "Lee", 28, "Member", "rover operator, drone pilot", "module 2-Δ", "miguel_lee@mars.org"],
        ["Anthony", "Carrington", 32, "Member", "doctor", "module 2-H", "anthony_carr_92@mars.org"],
        ["Arnold", "Smith", 26, "Member", "mechanic", "module 2-Ξ", "Arlnold_Smith98@mars.org"],
        ["Brendan", "Ayrton", 19, "Intern", "novice mechanic", "module 4-Σ", "Mecha_Brendan@mars.org"],
        ["Candice", "Durham", 27, "Third Captain", "main researcher", "module-3-Λ", "Can_To_Mars_Ice@mars.org"],
        ["Eric", "Roberts", 20, "Member", "researcher", "module 1-B", "MRoberts_4@mars.org"],
        ["Mark", "Gilmore", 31, "Fourth Captain", "main navigator", "module 1-B", "Mark_Navigator@mars.org"],
        ["John", "Edwards", 29, "Member", "second navigator", "module 2-A", "John_Edwards95@mars.org"],
        ["Nelly", "Conors", 35, "Member", "assistant", "module 3-Θ", "NellyCo_s89@mars.org"],
        ["Amber", "Rodriguez", 26, "Intern", "assistant", "module 4-Ψ", "Amber_9R8@mars.org"]
    ] + new_users):
        user = User()

        name = data[0]
        surname = data[1]
        age = data[2]
        position = data[3]
        speciality = data[4]
        address = data[5]
        email = data[6]
        hash = generate_password_hash(str(index + 1))

        print([str(index + 1)])

        user.name, user.surname, user.age, user.position, user.speciality, user.address, user.email, user.hashed_password = (
            name, surname, age, position, speciality, address, email, hash
        )

        db_sess.add(user)

    for data in [
        [1, "Check the serviceability of generators in modules 1 and 2.", 8, "2, 3", datetime.datetime.now(), False],
        [4, "Check the availability of the necessary medicines, check the serviceability of the life support system.",
         3, "4", datetime.datetime.now(), True],
        [5, "Fix problems with the tightness of the 3-Omega module.", 13, "5", datetime.datetime.now(), False],
        [7, "To study the physical and chemical properties of rocks from Mars", 38, "8", datetime.datetime.now(), True],
        [9, "To check the serviceability of the system management in practice.", 4, "10, 11, 12",
         datetime.datetime.now(), True],
        [1, "Go around the first 4 modules of the ship, settle down, distribute themselves into rooms and buildings.",
         16, "2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25", datetime.datetime.now(), True],
        [11, "Check for enough food.", 4, "12", datetime.datetime.now(), False]
    ]:
        job = Jobs()

        leader = data[0]
        work = data[1]
        work_size = data[2]
        collaborators = data[3]
        start_date = data[4]
        is_finished = data[5]

        job.team_leader, job.job, job.work_size, job.collaborators, job.start_date, job.is_finished = (
            leader, work, work_size, collaborators, start_date, is_finished
        )

        db_sess.add(job)

    for data in [
        ["Module 1", 1, "8, 9, 17", "module_1_@mars.org"],
        ["Module 2", 2, "3, 4, 5, 10, 14, 24", "module_2_@mars.org"],
        ["Module 3", 7, "11, 23", "module_3_@mars.org"],
        ["Module 4", 6, "12, 13, 16, 19, 22", "module_4_@mars.org"],
        ["Module 5", 21, "15", "module_5_@mars.org"],
        ["Module 6", 18, "20, 25", "module_6_@mars.org"],
        ["Corpus Alpha", 2, "10", "corpus_alpha_@mars.org"],
        ["Corpus Beta", 1, "8, 9", "corpus_beta_@mars.org"],
        ["Corpus Delta", 3, "13, 14", "corpus_delta_@mars.org"],
        ["Corpus Eta", 4, "15, 16", "corpus_eta_@mars.org"],
        ["Corpus Theta", 11, "17, 18", "corpus_teta_@mars.org"],
        ["Corpus Lambda", 7, "19, 20", "corpus_lambda_@mars.org"],
        ["Corpus Xi", 5, "21", "corpus_xi_@mars.org"],
        ["Corpus Sigma", 6, "22, 23", "corpus_sigma_@mars.org"],
        ["Corpus Psi", 12, "24, 25", "corpus_psi_@mars.org"]
    ]:

        dep = Departament()
        dep.title = data[0]
        dep.chief = data[1]
        dep.members = data[2]
        dep.email = data[3]

        db_sess.add(dep)

    db_sess.commit()


load_data()


def get_ids(job) -> list:
    return [job.team_leader] + list(map(int, job.collaborators.split(", ")))


def get_data(file_name) -> list:
    global_init(file_name)

    db_sess = create_session()

    result = []

    first_dep = db_sess.query(Departament).first()
    members_ids = [first_dep.chief] + list(map(int, first_dep.members.split(", ")))

    for member_id in members_ids:
        hours = 0
        for job in db_sess.query(Jobs):
            members_on_work = get_ids(job)

            if member_id in members_on_work and job.is_finished:
                hours += job.work_size

        if hours > 25:
            member = db_sess.query(User).filter(User.id == member_id)[0]
            print(member.surname, member.name)

    return result


@app.route("/")
def main():
    return render_template('main.html')


@app.route("/reg", methods=['GET', 'POST'])
@app.route("/register", methods=['GET', 'POST'])
def reg():
    form = RegisterForm()
    if form.validate_on_submit():
        if form.password.data != form.password_again.data:
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Пароли не совпадают")
        db_sess = create_session()
        if db_sess.query(User).filter(User.email == form.email.data).first():
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Такой пользователь уже есть")
        user = User()
        user.name = form.name.data
        user.surname = form.surname.data
        user.email = form.email.data
        user.age = form.age.data

        user.set_password(form.password.data)
        db_sess.add(user)
        db_sess.commit()
        return redirect('/login')
    return render_template('register.html', title='Регистрация', form=form)


@app.route('/login', methods=['GET', 'POST'])
@app.route('/log', methods=['GET', 'POST'])
@app.route('/authorization', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        db_sess = create_session()
        user = db_sess.query(User).filter(User.email == form.email.data).first()
        if user and user.check_password(form.password.data):
            login_user(user, remember=form.remember_me.data)
            return redirect("/")
        return render_template('login.html',
                               message="Неправильный логин или пароль",
                               form=form)
    return render_template('login.html', title='Авторизация', form=form)


@app.route("/journal")
def journal_of_works():
    global_init("db/blogs.db")

    db_sess = create_session()

    data = []

    tl = []  # TeamLeaders

    for job in db_sess.query(Jobs).all():
        team_leader = [user for user in db_sess.query(User).filter(User.id == job.team_leader)][0]
        data.append(
            [
                job.job,
                f"{team_leader.name} {team_leader.surname}",
                f"{job.work_size} hours",
                job.collaborators,
                "Is finished" if job.is_finished else "Isn't finished"
            ]
        )

        tl.append(team_leader.id)

    return render_template("journal_of_works.html", data=data, tl=tl)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect("/")


@app.route('/add_jobs',  methods=['GET', 'POST'])
@login_required
def add_jobs():
    form = JobsForm()
    form.submit.label = Label(form.submit.id, "Создать")
    if form.validate_on_submit():
        db_sess = create_session()
        jobs = Jobs()
        jobs.job = form.title.data
        jobs.team_leader = form.team_leader.data
        jobs.work_size = form.duration.data
        jobs.collaborators = form.collaborators.data
        jobs.is_finished = form.is_finished.data
        db_sess.add(jobs)
        db_sess.commit()
        return redirect('/journal')
    return render_template('jobs.html', title='Добавление работы',
                           form=form, n=0)


@app.route('/jobs/<int:id>', methods=['GET', 'POST'])
@app.route('/journal/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_news(id):
    form = JobsForm()
    form.submit.label = Label(form.submit.id, "Изменить")
    if request.method == "GET":
        db_sess = create_session()
        job = db_sess.query(Jobs).filter(Jobs.id == id, (Jobs.team_leader == current_user.id) | (current_user.id == 1)).first()
        if job:
            form.title.data = job.job
            form.team_leader.data = job.team_leader
            form.duration.data = job.work_size
            form.is_finished.data = job.is_finished
            form.collaborators.data = job.collaborators
        else:
            print("Кажется, у вас нет прав к изменению этой новости...")
    if form.validate_on_submit():
        db_sess = create_session()
        jobs = db_sess.query(Jobs).filter(Jobs.id == id, (Jobs.team_leader == current_user.id) | (current_user.id == 1)).first()
        if jobs:
            jobs.title = form.title.data
            jobs.team_leader = form.team_leader.data
            jobs.work_size = form.duration.data
            jobs.collaborators = form.collaborators.data
            jobs.is_finished = form.is_finished.data
            db_sess.commit()
            return redirect('/journal')
        else:
            abort(404)
    return render_template('jobs.html',
                           title='Редактирование работы',
                           form=form)


@app.route('/jobs_delete/<int:id>', methods=['GET', 'POST'])
@login_required
def jobs_delete(id):
    db_sess = create_session()
    job = db_sess.query(Jobs).filter(Jobs.id == id).first()
    if job:
        db_sess.delete(job)
        db_sess.commit()
    else:
        abort(404)
    return redirect('/journal')


@app.route('/dep', methods=['GET', 'POST'])
def departments():
    global_init("db/blogs.db")

    db_sess = create_session()

    data = []

    tl = []  # TeamLeaders

    for dep in db_sess.query(Departament).all():
        chief = [user for user in db_sess.query(User).filter(User.id == dep.chief)][0]
        c_name = f"{chief.name} {chief.surname}"

        data.append([dep.title, c_name, dep.members, dep.email])

        tl.append(chief.id)

    return render_template("departments.html", data=data, tl=tl)


get_data("db/blogs.db")

if __name__ == '__main__':
    app.run(port=8880, host='127.0.0.1')
